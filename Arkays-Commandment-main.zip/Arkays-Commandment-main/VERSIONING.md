1.0.x are save game safe.

1.x.x may require a new save game.

x.0.0 definitely requires a new save game.
